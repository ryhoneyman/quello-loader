-- MariaDB dump 10.19  Distrib 10.6.16-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: quarm
-- ------------------------------------------------------
-- Server version	10.6.16-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quello_character_alternate_abilities`
--

DROP TABLE IF EXISTS `quello_character_alternate_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_alternate_abilities` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `slot` smallint(11) unsigned NOT NULL DEFAULT 0,
  `aa_id` smallint(11) unsigned NOT NULL DEFAULT 0,
  `aa_value` smallint(11) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_alternate_abilities`
--

LOCK TABLES `quello_character_alternate_abilities` WRITE;
/*!40000 ALTER TABLE `quello_character_alternate_abilities` DISABLE KEYS */;
INSERT INTO `quello_character_alternate_abilities` VALUES (168178,0,64,3),(168178,1,1005,3),(168178,2,109,3),(168178,3,115,3),(168178,4,124,3),(168178,5,127,3),(168178,6,128,1),(168178,7,198,1),(168178,8,201,3),(168178,9,205,1);
/*!40000 ALTER TABLE `quello_character_alternate_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_bind`
--

DROP TABLE IF EXISTS `quello_character_bind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_bind` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `is_home` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `zone_id` smallint(11) unsigned NOT NULL DEFAULT 0,
  `x` float NOT NULL DEFAULT 0,
  `y` float NOT NULL DEFAULT 0,
  `z` float NOT NULL DEFAULT 0,
  `heading` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_bind`
--

LOCK TABLES `quello_character_bind` WRITE;
/*!40000 ALTER TABLE `quello_character_bind` DISABLE KEYS */;
INSERT INTO `quello_character_bind` VALUES (168177,0,54,64,192,33,0),(168177,1,54,64,192,33,0),(168178,0,4,-46,4850,1,0),(168178,1,4,-46,4850,1,0),(168179,0,4,-46,4850,1,0),(168179,1,4,-46,4850,1,0);
/*!40000 ALTER TABLE `quello_character_bind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_currency`
--

DROP TABLE IF EXISTS `quello_character_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_currency` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `platinum` int(11) unsigned NOT NULL DEFAULT 0,
  `gold` int(11) unsigned NOT NULL DEFAULT 0,
  `silver` int(11) unsigned NOT NULL DEFAULT 0,
  `copper` int(11) unsigned NOT NULL DEFAULT 0,
  `platinum_bank` int(11) unsigned NOT NULL DEFAULT 0,
  `gold_bank` int(11) unsigned NOT NULL DEFAULT 0,
  `silver_bank` int(11) unsigned NOT NULL DEFAULT 0,
  `copper_bank` int(11) unsigned NOT NULL DEFAULT 0,
  `platinum_cursor` int(11) unsigned NOT NULL DEFAULT 0,
  `gold_cursor` int(11) unsigned NOT NULL DEFAULT 0,
  `silver_cursor` int(11) unsigned NOT NULL DEFAULT 0,
  `copper_cursor` int(11) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_currency`
--

LOCK TABLES `quello_character_currency` WRITE;
/*!40000 ALTER TABLE `quello_character_currency` DISABLE KEYS */;
INSERT INTO `quello_character_currency` VALUES (168177,4523,7,5,0,100,1000,10000,50000,0,0,0,0),(168178,960,0,0,0,10,100,1000,10000,0,0,0,0),(168179,5000,0,0,0,500,400,300,200,0,0,0,0);
/*!40000 ALTER TABLE `quello_character_currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_data`
--

DROP TABLE IF EXISTS `quello_character_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_data` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `last_name` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `title` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `suffix` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `zone_id` int(11) unsigned NOT NULL DEFAULT 0,
  `y` float NOT NULL DEFAULT 0,
  `x` float NOT NULL DEFAULT 0,
  `z` float NOT NULL DEFAULT 0,
  `heading` float NOT NULL DEFAULT 0,
  `gender` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `race` smallint(11) unsigned NOT NULL DEFAULT 0,
  `class` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `level` int(11) unsigned NOT NULL DEFAULT 0,
  `deity` int(11) unsigned NOT NULL DEFAULT 0,
  `birthday` int(11) unsigned NOT NULL DEFAULT 0,
  `last_login` int(11) unsigned NOT NULL DEFAULT 0,
  `time_played` int(11) unsigned NOT NULL DEFAULT 0,
  `level2` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `anon` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `gm` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `face` int(11) unsigned NOT NULL DEFAULT 0,
  `hair_color` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `hair_style` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `beard` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `beard_color` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `eye_color_1` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `eye_color_2` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `exp` int(11) unsigned NOT NULL DEFAULT 0,
  `aa_points_spent` int(11) unsigned NOT NULL DEFAULT 0,
  `aa_exp` int(11) unsigned NOT NULL DEFAULT 0,
  `aa_points` int(11) unsigned NOT NULL DEFAULT 0,
  `points` int(11) unsigned NOT NULL DEFAULT 0,
  `cur_hp` int(11) unsigned NOT NULL DEFAULT 0,
  `mana` int(11) unsigned NOT NULL DEFAULT 0,
  `endurance` int(11) unsigned NOT NULL DEFAULT 0,
  `intoxication` int(11) unsigned NOT NULL DEFAULT 0,
  `str` int(11) unsigned NOT NULL DEFAULT 0,
  `sta` int(11) unsigned NOT NULL DEFAULT 0,
  `cha` int(11) unsigned NOT NULL DEFAULT 0,
  `dex` int(11) unsigned NOT NULL DEFAULT 0,
  `int` int(11) unsigned NOT NULL DEFAULT 0,
  `agi` int(11) unsigned NOT NULL DEFAULT 0,
  `wis` int(11) unsigned NOT NULL DEFAULT 0,
  `zone_change_count` int(11) unsigned NOT NULL DEFAULT 0,
  `hunger_level` int(11) unsigned NOT NULL DEFAULT 0,
  `thirst_level` int(11) unsigned NOT NULL DEFAULT 0,
  `pvp_status` tinyint(11) unsigned NOT NULL DEFAULT 0,
  `air_remaining` int(11) unsigned NOT NULL DEFAULT 0,
  `autosplit_enabled` int(11) unsigned NOT NULL DEFAULT 0,
  `mailkey` char(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `firstlogon` tinyint(3) NOT NULL DEFAULT 0,
  `e_aa_effects` int(11) unsigned NOT NULL DEFAULT 0,
  `e_percent_to_aa` int(11) unsigned NOT NULL DEFAULT 0,
  `e_expended_aa_spent` int(11) unsigned NOT NULL DEFAULT 0,
  `boatid` int(11) unsigned NOT NULL DEFAULT 0,
  `boatname` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `famished` int(11) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `showhelm` tinyint(4) NOT NULL DEFAULT 1,
  `fatigue` int(11) DEFAULT 0,
  `e_self_found` tinyint(4) NOT NULL DEFAULT 0,
  `e_solo_only` tinyint(4) NOT NULL DEFAULT 0,
  `e_hardcore` tinyint(4) NOT NULL DEFAULT 0,
  `e_hardcore_death_time` bigint(22) NOT NULL DEFAULT 0,
  `e_betabuff_gear_flag` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `e_zone_guild_id` int(11) unsigned NOT NULL DEFAULT 4294967295,
  `e_temp_last_name` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `e_married_character_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_data`
--

LOCK TABLES `quello_character_data` WRITE;
/*!40000 ALTER TABLE `quello_character_data` DISABLE KEYS */;
INSERT INTO `quello_character_data` VALUES (168177,'Talodarz','','','',71,-129,-468,-352.9,324,0,4,6,50,215,1718980254,1718981355,4,50,0,1,0,14,0,255,255,3,3,165120248,0,0,0,250,955,1263,0,0,65,80,75,80,75,95,115,4,32000,32000,0,50,0,'',0,0,0,0,0,'',0,0,1,0,0,0,0,0,1,4294967295,'',0),(168178,'Zephonz','','','',108,37,1698,31.8,6,0,7,4,65,207,1718980297,1718982703,16,65,0,1,7,13,0,255,255,7,7,175000000,99,0,1,325,1212,848,0,0,75,100,75,85,75,100,65,10,32000,32000,0,70,0,'',0,0,0,0,0,'',0,0,1,0,0,0,0,0,1,4294967295,'',0),(168179,'Icestormz','','','',19,98,-166,6.9,284,0,1,6,50,207,1718980323,1718980995,11,50,0,0,4,14,0,255,255,9,9,165737732,0,0,0,250,78,238,0,0,75,90,75,75,75,75,110,1,4084,4084,0,60,0,'',0,0,0,0,0,'',0,0,1,0,0,0,0,0,1,4294967295,'',0);
/*!40000 ALTER TABLE `quello_character_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_faction_values`
--

DROP TABLE IF EXISTS `quello_character_faction_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_faction_values` (
  `id` int(11) NOT NULL DEFAULT 0,
  `faction_id` int(4) NOT NULL DEFAULT 0,
  `current_value` smallint(6) NOT NULL DEFAULT 0,
  `temp` tinyint(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_faction_values`
--

LOCK TABLES `quello_character_faction_values` WRITE;
/*!40000 ALTER TABLE `quello_character_faction_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `quello_character_faction_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_inventory`
--

DROP TABLE IF EXISTS `quello_character_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_inventory` (
  `id` int(11) NOT NULL DEFAULT 0,
  `slotid` mediumint(7) unsigned NOT NULL DEFAULT 0,
  `itemid` int(11) unsigned DEFAULT 0,
  `charges` smallint(3) unsigned DEFAULT 0,
  `custom_data` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `serialnumber` int(10) NOT NULL DEFAULT 0,
  `initialserial` tinyint(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_inventory`
--

LOCK TABLES `quello_character_inventory` WRITE;
/*!40000 ALTER TABLE `quello_character_inventory` DISABLE KEYS */;
INSERT INTO `quello_character_inventory` VALUES (168177,2,2249,1,'',0,0),(168177,3,2250,1,'',0,0),(168177,5,2251,1,'',0,0),(168177,6,2253,1,'',0,0),(168177,7,2256,1,'',0,0),(168177,8,2254,1,'',0,0),(168177,9,2257,1,'',0,0),(168177,10,2257,1,'',0,0),(168177,12,2258,1,'',0,0),(168177,13,6352,1,'',0,0),(168177,17,2252,1,'',0,0),(168177,18,2259,1,'',0,0),(168177,19,2260,1,'',0,0),(168177,20,2255,1,'',0,0),(168177,22,20912,1,'',0,0),(168177,23,20911,1,'',0,0),(168177,24,9991,20,'',0,0),(168177,25,17046,1,'',0,0),(168177,26,17046,1,'',0,0),(168177,280,9990,20,'',0,0),(168177,2000,9993,1,'',0,0),(168177,2001,17046,1,'',0,0),(168177,2002,9999,1,'',0,0),(168177,2006,18786,1,'',0,0),(168177,2040,9984,1,'',0,0),(168178,3,3054,1,'',0,0),(168178,5,3055,1,'',0,0),(168178,6,3057,1,'',0,0),(168178,7,3060,1,'',0,0),(168178,8,3058,1,'',0,0),(168178,9,3061,1,'',0,0),(168178,10,3061,1,'',0,0),(168178,12,3062,1,'',0,0),(168178,13,9998,1,'',0,0),(168178,17,3056,1,'',0,0),(168178,18,3063,1,'',0,0),(168178,19,3064,1,'',0,0),(168178,20,3059,1,'',0,0),(168178,22,20602,1,'',0,0),(168178,23,9990,20,'',0,0),(168178,24,20601,1,'',0,0),(168178,25,17046,1,'',0,0),(168178,26,17046,1,'',0,0),(168178,27,20884,1,'',0,0),(168178,290,9991,20,'',0,0),(168178,2000,17046,1,'',0,0),(168178,2004,3053,1,'',0,0),(168178,2030,6352,1,'',0,0),(168178,2031,18709,1,'',0,0),(168179,2,2237,1,'',0,0),(168179,3,2238,1,'',0,0),(168179,5,2239,1,'',0,0),(168179,6,2241,1,'',0,0),(168179,7,2244,1,'',0,0),(168179,8,2242,1,'',0,0),(168179,9,2245,1,'',0,0),(168179,10,2245,1,'',0,0),(168179,12,2246,1,'',0,0),(168179,13,6352,1,'',0,0),(168179,17,2240,1,'',0,0),(168179,20,2243,1,'',0,0),(168179,22,9990,20,'',0,0),(168179,23,9991,20,NULL,0,0),(168179,24,17969,1,'',0,0),(168179,27,17046,1,'',0,0),(168179,28,17046,1,'',0,0),(168179,310,2247,1,'',0,0),(168179,311,6350,1,'',0,0),(168179,312,6352,1,'',0,0),(168179,313,9002,1,'',0,0),(168179,314,7352,1,'',0,0),(168179,315,7350,1,'',0,0),(168179,316,6359,1,'',0,0),(168179,2000,9993,1,'',0,0),(168179,2001,9979,1,'',0,0),(168179,2002,17046,1,'',0,0),(168179,2004,18713,1,'',0,0),(168179,2005,17969,1,'',0,0),(168179,2080,9984,1,'',0,0),(168179,2081,9999,1,'',0,0);
/*!40000 ALTER TABLE `quello_character_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_keyring`
--

DROP TABLE IF EXISTS `quello_character_keyring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_keyring` (
  `id` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_keyring`
--

LOCK TABLES `quello_character_keyring` WRITE;
/*!40000 ALTER TABLE `quello_character_keyring` DISABLE KEYS */;
INSERT INTO `quello_character_keyring` VALUES (168177,20911),(168177,20912),(168178,20884);
/*!40000 ALTER TABLE `quello_character_keyring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_languages`
--

DROP TABLE IF EXISTS `quello_character_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_languages` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `lang_id` smallint(11) unsigned NOT NULL DEFAULT 0,
  `value` smallint(11) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_languages`
--

LOCK TABLES `quello_character_languages` WRITE;
/*!40000 ALTER TABLE `quello_character_languages` DISABLE KEYS */;
INSERT INTO `quello_character_languages` VALUES (168177,0,100),(168177,3,100),(168178,0,100),(168178,3,100),(168179,0,100);
/*!40000 ALTER TABLE `quello_character_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_skills`
--

DROP TABLE IF EXISTS `quello_character_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_skills` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `skill_id` smallint(11) unsigned NOT NULL DEFAULT 0,
  `value` smallint(11) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_skills`
--

LOCK TABLES `quello_character_skills` WRITE;
/*!40000 ALTER TABLE `quello_character_skills` DISABLE KEYS */;
INSERT INTO `quello_character_skills` VALUES (168177,0,175),(168177,1,175),(168177,2,175),(168177,3,0),(168177,4,235),(168177,5,235),(168177,6,0),(168177,7,0),(168177,8,0),(168177,9,200),(168177,10,0),(168177,11,0),(168177,12,0),(168177,13,200),(168177,14,235),(168177,15,200),(168177,16,0),(168177,17,0),(168177,18,235),(168177,19,75),(168177,20,0),(168177,21,0),(168177,22,0),(168177,23,0),(168177,24,235),(168177,25,0),(168177,26,0),(168177,27,200),(168177,28,75),(168177,29,50),(168177,30,0),(168177,31,240),(168177,32,0),(168177,33,200),(168177,34,0),(168177,35,0),(168177,36,0),(168177,37,0),(168177,38,0),(168177,39,0),(168177,40,200),(168177,41,0),(168177,42,0),(168177,43,200),(168177,44,50),(168177,45,50),(168177,46,50),(168177,47,50),(168177,48,0),(168177,49,0),(168177,50,200),(168177,51,0),(168177,52,0),(168177,53,125),(168177,54,0),(168177,55,200),(168177,56,0),(168177,57,0),(168177,58,0),(168177,59,0),(168177,60,250),(168177,61,250),(168177,62,0),(168177,63,250),(168177,64,250),(168177,65,250),(168177,66,200),(168177,67,200),(168177,68,250),(168177,69,250),(168177,70,0),(168177,71,0),(168177,72,0),(168177,73,0),(168178,0,200),(168178,1,200),(168178,2,200),(168178,3,200),(168178,4,205),(168178,5,205),(168178,6,0),(168178,7,200),(168178,8,0),(168178,9,150),(168178,10,0),(168178,11,0),(168178,12,0),(168178,13,200),(168178,14,205),(168178,15,200),(168178,16,55),(168178,17,0),(168178,18,205),(168178,19,137),(168178,20,200),(168178,21,0),(168178,22,205),(168178,23,0),(168178,24,205),(168178,25,0),(168178,26,0),(168178,27,200),(168178,28,100),(168178,29,75),(168178,30,149),(168178,31,185),(168178,32,0),(168178,33,200),(168178,34,185),(168178,35,0),(168178,36,200),(168178,37,150),(168178,38,0),(168178,39,0),(168178,40,200),(168178,41,0),(168178,42,75),(168178,43,0),(168178,44,0),(168178,45,0),(168178,46,0),(168178,47,0),(168178,48,0),(168178,49,0),(168178,50,200),(168178,51,113),(168178,52,0),(168178,53,200),(168178,54,0),(168178,55,200),(168178,56,0),(168178,57,0),(168178,58,0),(168178,59,0),(168178,60,250),(168178,61,250),(168178,62,0),(168178,63,250),(168178,64,250),(168178,65,250),(168178,66,200),(168178,67,200),(168178,68,250),(168178,69,250),(168178,70,0),(168178,71,0),(168178,72,0),(168178,73,150),(168179,0,175),(168179,1,175),(168179,2,175),(168179,3,0),(168179,4,235),(168179,5,235),(168179,6,0),(168179,7,0),(168179,8,0),(168179,9,200),(168179,10,0),(168179,11,0),(168179,12,0),(168179,13,200),(168179,14,235),(168179,15,200),(168179,16,0),(168179,17,0),(168179,18,235),(168179,19,75),(168179,20,0),(168179,21,0),(168179,22,0),(168179,23,0),(168179,24,235),(168179,25,0),(168179,26,0),(168179,27,200),(168179,28,75),(168179,29,0),(168179,30,0),(168179,31,240),(168179,32,0),(168179,33,200),(168179,34,0),(168179,35,0),(168179,36,0),(168179,37,0),(168179,38,0),(168179,39,0),(168179,40,200),(168179,41,0),(168179,42,0),(168179,43,200),(168179,44,50),(168179,45,50),(168179,46,50),(168179,47,50),(168179,48,0),(168179,49,0),(168179,50,200),(168179,51,0),(168179,52,0),(168179,53,125),(168179,54,0),(168179,55,200),(168179,56,0),(168179,57,0),(168179,58,0),(168179,59,0),(168179,60,250),(168179,61,250),(168179,62,0),(168179,63,250),(168179,64,250),(168179,65,250),(168179,66,200),(168179,67,200),(168179,68,250),(168179,69,250),(168179,70,0),(168179,71,0),(168179,72,0),(168179,73,0);
/*!40000 ALTER TABLE `quello_character_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_spells`
--

DROP TABLE IF EXISTS `quello_character_spells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_spells` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `slot_id` smallint(11) unsigned NOT NULL DEFAULT 0,
  `spell_id` smallint(11) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_spells`
--

LOCK TABLES `quello_character_spells` WRITE;
/*!40000 ALTER TABLE `quello_character_spells` DISABLE KEYS */;
INSERT INTO `quello_character_spells` VALUES (168177,0,12),(168177,1,15),(168177,2,17),(168177,3,26),(168177,4,27),(168177,5,28),(168177,6,29),(168177,7,34),(168177,8,35),(168177,9,36),(168177,10,48),(168177,11,49),(168177,12,50),(168177,13,57),(168177,14,60),(168177,15,61),(168177,16,62),(168177,17,63),(168177,18,64),(168177,19,76),(168177,20,77),(168177,21,78),(168177,22,80),(168177,23,86),(168177,24,91),(168177,25,92),(168177,26,93),(168177,27,95),(168177,28,96),(168177,29,99),(168177,30,115),(168177,31,116),(168177,32,129),(168177,33,137),(168177,34,138),(168177,35,139),(168177,36,140),(168177,37,141),(168177,38,142),(168177,39,143),(168177,40,144),(168177,41,145),(168177,42,169),(168177,43,200),(168177,44,203),(168177,45,211),(168177,46,213),(168177,47,217),(168177,48,220),(168177,49,222),(168177,50,224),(168177,51,225),(168177,52,226),(168177,53,227),(168177,54,228),(168177,55,234),(168177,56,237),(168177,57,238),(168177,58,239),(168177,59,240),(168177,60,241),(168177,61,242),(168177,62,245),(168177,63,247),(168177,64,248),(168177,65,249),(168177,66,250),(168177,67,252),(168177,68,253),(168177,69,254),(168177,70,255),(168177,71,256),(168177,72,257),(168177,73,258),(168177,74,259),(168177,75,260),(168177,76,261),(168177,77,262),(168177,78,263),(168177,79,264),(168177,80,268),(168177,81,273),(168177,82,278),(168177,83,356),(168177,84,405),(168177,85,406),(168177,86,417),(168177,87,418),(168177,88,419),(168177,89,420),(168177,90,421),(168177,91,422),(168177,92,423),(168177,93,424),(168177,94,425),(168177,95,426),(168177,96,427),(168177,97,428),(168177,98,429),(168177,99,430),(168177,100,432),(168177,101,433),(168177,102,490),(168177,103,512),(168177,104,513),(168177,105,514),(168177,106,515),(168177,107,516),(168177,108,517),(168177,109,518),(168177,110,519),(168177,111,520),(168177,112,530),(168177,113,531),(168177,114,532),(168177,115,533),(168177,116,534),(168177,117,535),(168177,118,536),(168177,119,537),(168177,120,538),(168177,121,550),(168177,122,551),(168177,123,552),(168177,124,553),(168177,125,554),(168177,126,555),(168177,127,556),(168177,128,557),(168177,129,558),(168177,130,607),(168177,131,608),(168177,132,609),(168177,133,610),(168177,134,611),(168177,135,663),(168177,136,664),(168177,137,665),(168177,138,671),(168177,139,753),(168177,140,1285),(168177,141,1326),(168177,142,1392),(168177,143,1398),(168177,144,1433),(168177,145,1434),(168177,146,1435),(168177,147,1436),(168177,148,1437),(168177,149,1438),(168177,150,1439),(168177,151,1440),(168177,152,1517),(168177,153,1736),(168177,154,1737),(168177,155,1740),(168177,156,1776),(168177,157,1800),(168177,158,1888),(168177,159,2020),(168177,160,2021),(168177,161,2029),(168177,162,2030),(168177,163,2031),(168177,164,2110),(168177,165,2111),(168177,166,2183),(168177,167,2417),(168177,168,2419),(168177,169,2422),(168177,170,2424),(168177,171,2427),(168177,172,2429),(168177,173,2432),(168177,174,2433),(168177,175,2511),(168177,176,2512),(168177,177,2513),(168177,178,2514),(168177,179,2515),(168177,180,2591),(168177,181,2946),(168177,182,3182),(168177,183,3184),(168177,184,3255),(168177,185,3256),(168177,186,3257),(168177,187,3277),(168177,188,3278),(168177,189,3279),(168177,190,3579),(168177,191,3580),(168177,192,3583),(168177,193,3601),(168177,194,3695),(168177,195,3792),(168177,196,3794),(168177,197,3834),(168177,198,3998),(168178,0,12),(168178,1,17),(168178,2,26),(168178,3,48),(168178,4,51),(168178,5,80),(168178,6,86),(168178,7,91),(168178,8,92),(168178,9,115),(168178,10,200),(168178,11,203),(168178,12,213),(168178,13,222),(168178,14,224),(168178,15,225),(168178,16,237),(168178,17,239),(168178,18,240),(168178,19,241),(168178,20,242),(168178,21,247),(168178,22,248),(168178,23,249),(168178,24,250),(168178,25,252),(168178,26,254),(168178,27,256),(168178,28,261),(168178,29,263),(168178,30,264),(168178,31,268),(168178,32,269),(168178,33,278),(168178,34,419),(168178,35,421),(168178,36,500),(168178,37,513),(168178,38,515),(168178,39,516),(168178,40,517),(168178,41,655),(168178,42,1461),(168178,43,1776),(168178,44,2110),(168178,45,2591),(168178,46,2592),(168178,47,2593),(168178,48,2594),(168178,49,3564),(168178,50,3565),(168178,51,3601),(168179,0,12),(168179,1,15),(168179,2,17),(168179,3,26),(168179,4,27),(168179,5,28),(168179,6,29),(168179,7,34),(168179,8,35),(168179,9,36),(168179,10,48),(168179,11,49),(168179,12,50),(168179,13,57),(168179,14,60),(168179,15,61),(168179,16,62),(168179,17,63),(168179,18,64),(168179,19,76),(168179,20,77),(168179,21,78),(168179,22,80),(168179,23,86),(168179,24,91),(168179,25,92),(168179,26,93),(168179,27,95),(168179,28,96),(168179,29,99),(168179,30,115),(168179,31,116),(168179,32,129),(168179,33,137),(168179,34,138),(168179,35,139),(168179,36,140),(168179,37,141),(168179,38,142),(168179,39,143),(168179,40,144),(168179,41,145),(168179,42,169),(168179,43,200),(168179,44,203),(168179,45,211),(168179,46,213),(168179,47,217),(168179,48,220),(168179,49,222),(168179,50,224),(168179,51,225),(168179,52,226),(168179,53,227),(168179,54,228),(168179,55,234),(168179,56,237),(168179,57,238),(168179,58,239),(168179,59,240),(168179,60,241),(168179,61,242),(168179,62,245),(168179,63,247),(168179,64,248),(168179,65,249),(168179,66,250),(168179,67,252),(168179,68,253),(168179,69,254),(168179,70,255),(168179,71,256),(168179,72,257),(168179,73,258),(168179,74,259),(168179,75,260),(168179,76,261),(168179,77,262),(168179,78,263),(168179,79,264),(168179,80,268),(168179,81,273),(168179,82,278),(168179,83,356),(168179,84,405),(168179,85,406),(168179,86,417),(168179,87,418),(168179,88,419),(168179,89,420),(168179,90,421),(168179,91,422),(168179,92,423),(168179,93,424),(168179,94,425),(168179,95,426),(168179,96,427),(168179,97,428),(168179,98,429),(168179,99,430),(168179,100,432),(168179,101,433),(168179,102,490),(168179,103,512),(168179,104,513),(168179,105,514),(168179,106,515),(168179,107,516),(168179,108,517),(168179,109,518),(168179,110,519),(168179,111,520),(168179,112,530),(168179,113,531),(168179,114,532),(168179,115,533),(168179,116,534),(168179,117,535),(168179,118,536),(168179,119,537),(168179,120,538),(168179,121,550),(168179,122,551),(168179,123,552),(168179,124,553),(168179,125,554),(168179,126,555),(168179,127,556),(168179,128,557),(168179,129,558),(168179,130,607),(168179,131,608),(168179,132,609),(168179,133,610),(168179,134,611),(168179,135,663),(168179,136,664),(168179,137,665),(168179,138,671),(168179,139,753),(168179,140,1285),(168179,141,1326),(168179,142,1398),(168179,143,1433),(168179,144,1434),(168179,145,1435),(168179,146,1436),(168179,147,1437),(168179,148,1438),(168179,149,1439),(168179,150,1440),(168179,151,1517),(168179,152,1736),(168179,153,1737),(168179,154,1740),(168179,155,1800),(168179,156,1888),(168179,157,2020),(168179,158,2021),(168179,159,2029),(168179,160,2030),(168179,161,2031),(168179,162,2183),(168179,163,2417),(168179,164,2419),(168179,165,2422),(168179,166,2424),(168179,167,2427),(168179,168,2429),(168179,169,2432),(168179,170,2433),(168179,171,2511),(168179,172,2512),(168179,173,2513),(168179,174,2514),(168179,175,2515),(168179,176,2591),(168179,177,2946),(168179,178,3182),(168179,179,3184),(168179,180,3579),(168179,181,3580),(168179,182,3583),(168179,183,3601),(168179,184,1392),(168179,185,1776),(168179,186,2110),(168179,187,2111),(168179,188,3255),(168179,189,3256),(168179,190,3257),(168179,191,3277),(168179,192,3278),(168179,193,3279),(168179,194,3695),(168179,195,3792),(168179,196,3794),(168179,197,3834),(168179,198,3998);
/*!40000 ALTER TABLE `quello_character_spells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_character_zone_flags`
--

DROP TABLE IF EXISTS `quello_character_zone_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_character_zone_flags` (
  `id` int(11) NOT NULL DEFAULT 0,
  `zoneID` int(11) NOT NULL DEFAULT 0,
  `key_` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_character_zone_flags`
--

LOCK TABLES `quello_character_zone_flags` WRITE;
/*!40000 ALTER TABLE `quello_character_zone_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `quello_character_zone_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_guild_members`
--

DROP TABLE IF EXISTS `quello_guild_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_guild_members` (
  `char_id` int(11) NOT NULL DEFAULT 0,
  `guild_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rank` tinyint(3) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_guild_members`
--

LOCK TABLES `quello_guild_members` WRITE;
/*!40000 ALTER TABLE `quello_guild_members` DISABLE KEYS */;
INSERT INTO `quello_guild_members` VALUES (168179,1,2);
/*!40000 ALTER TABLE `quello_guild_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quello_guilds`
--

DROP TABLE IF EXISTS `quello_guilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quello_guilds` (
  `id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  `leader` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quello_guilds`
--

LOCK TABLES `quello_guilds` WRITE;
/*!40000 ALTER TABLE `quello_guilds` DISABLE KEYS */;
INSERT INTO `quello_guilds` VALUES (1,'Aperture Science',168179);
/*!40000 ALTER TABLE `quello_guilds` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21 19:18:52
